﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VueJSDotnet51.Models
{
    public class SaveExcelModel
    {
        public string base64 { get; set; }
        public string fileName { get; set; }

    }
}
