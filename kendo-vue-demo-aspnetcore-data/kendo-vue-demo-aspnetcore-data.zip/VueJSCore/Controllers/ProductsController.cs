﻿using Microsoft.AspNetCore.Mvc;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using SmartIT.Employee.MockDB;
using Microsoft.AspNetCore.Hosting;
using System;
using System.IO;
using VueJSDotnet51.Models;

namespace kendo_ui_vue_demo_aspnetcore_data.Controllers
{


    [Route("api/Save")]
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpPost]
        public IActionResult Save([FromBody] SaveExcelModel body)
        {
            string contentRootPath = _webHostEnvironment.ContentRootPath;
            var path = Path.Combine(contentRootPath, "AppData\\", body.fileName);

            byte[] data = Convert.FromBase64String(body.base64);
            System.IO.File.WriteAllBytes(path, data);

            return new EmptyResult();
        }
    }

    [Produces("application/json")]
    [Route("api/Employee")]
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;
        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        // GET: api/Employee
        [HttpGet]
        public JsonResult GetEmployee([DataSourceRequest] DataSourceRequest request)
        {
            // ToDataSourceResult works with IQueryable and thus Entity Framework could be used as a source
            // instead of an in-memory list.
            var employees = _employeeRepository.GetAll();
            return Json(employees.ToDataSourceResult(request));
        }
        // POST: api/Employee
        [HttpPost]
        public JsonResult AddEmployee([DataSourceRequest] DataSourceRequest request, Employee employee)
        {
            // ToDataSourceResult works with IQueryable and thus Entity Framework could be used as a source
            // instead of an in-memory list.
            _employeeRepository.Add(employee);
            var employees = _employeeRepository.GetAll();
            return Json(employees.ToDataSourceResult(request));
        }
        // PUT: api/Employee
        [HttpPut]
        public JsonResult UpdateEmployee([DataSourceRequest] DataSourceRequest request, Employee employee)
        {
            // ToDataSourceResult works with IQueryable and thus Entity Framework could be used as a source
            // instead of an in-memory list.

            var test = _employeeRepository.Update(employee);
            var employees = _employeeRepository.GetAll();
            return Json(employees.ToDataSourceResult(request));
        }
        // DELETE: api/Employee
        [HttpDelete]
        public JsonResult DeleteEmployee([DataSourceRequest] DataSourceRequest request, Employee employee)
        {
            // ToDataSourceResult works with IQueryable and thus Entity Framework could be used as a source
            // instead of an in-memory list.
            var findEmployee = _employeeRepository.FindbyId(employee.Id);
            _employeeRepository.Delete(findEmployee);
            var employees = _employeeRepository.GetAll();
            return Json(employees.ToDataSourceResult(request));
        }

    }
}
